const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Router = express.Router();
const multer = require('multer');
const User = mongoose.model("User")
const jwt = require('jsonwebtoken');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'public/')
    },

    filename: function(req, file, cb){
        cb(null, file.originalname)
    }
});

const fileFilter = (req, file, cb) => {
    if(file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'image/jpg'){
        cb(null, true);
    }
    else{
        cb(null, false);
    }
    
    
};

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5
    },
    fileFilter: fileFilter

        });

Router.post('/sign-up', upload.single('productImage'), async (req, res, next) => {

    console.log(req.body);
    User.find({email: req.body.email})
    .exec()
    .then(user => {
        if(user.length >=1){
            res.status(409).json({
                Message: "User already exists"
            })
        }
        else{

            bcrypt.hash(req.body.password, 10, (err, hash) => {

                if(err){
                    res.status(500).json({
                        Error: "Error whilst hasting"
                    });
                }
                else{
                    const user = new User({
                        _id: mongoose.Types.ObjectId(),
                        name: req.body.name,
                        email: req.body.email,
                        password: hash,
                        profileImage: req.file.filename
                    });
        
                    user
                    .save()
                    .then( result => {
                        console.log(result);
                        res.status(200).json({
                            Message: "Saved User"
                        });
                    })
                    .catch(err => {
                        console.log(err);
                        res.status(500).json({
                            Error: err,
                            Message:"Not Saved"
                        })
                    });
                }
        
        
           });

        }
    })
    .catch();


});

Router.post('/login',(req, res, next) => {

    
    User.find({email: req.body.email})
    .exec()
    .then(user => {

        if(user.length < 1){

          return  res.status(401).json({
                "Auth": "Auth Failed"
            });
        }
        bcrypt.compare(req.body.password,user[0].password, (err, result)=>{
            if(err){

                return  res.status(401).json({
                    "Auth": "Auth Failed"
                });
            }
            if(result){
              const token =  jwt.sign({
                    email: user[0].email,
                    id: user[0]._id

                },
                process.env.JWT_KEY,
                {
                    expiresIn: '1h'
                }
                );
                return  res.status(200).json({
                    Auth: "Auth Successfull",
                    Token : token,
                    name: user[0].name,
                    id: user[0]._id
                });

            }
            return  res.status(401).json({
                "Auth": "Auth Successfull"
            });
        })
    })
    .catch(err => {

        return  res.status(401).json({
            "Auth": "not successfull"
        });

    });
});

//Detele user is pending


module.exports = Router;