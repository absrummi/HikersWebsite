const mongoose = require("mongoose");

const post_schema = mongoose.Schema({
    title: {
        type: String,
        required: "Title Required"
    },
    category: {
        type: String,
        required: "Content Required"
    },
    backgroundImage: {
        type: String,
        required: true
    },
    contentImage: {
        type: String,
        required: true
    },
    aboutPost: {
        type: String,
        required: true
    },
    userID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: "User ID is required field"
    },
    comments: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Comment",
        required: "Comment is required"
    }]
},
{
    timestamps: true
}
);


module.exports = mongoose.model("Post", post_schema)