$(document).ready(() => {

    
    $('.glyphicon-remove').on('click', function() {
        var commentID = $(this).text();
        console.log(commentID);
        $.ajax({
            type: 'delete',
            url: 'http://localhost:3001/posts/comment/'+commentID,
            success: () => {
                location.reload();
            }
        });
    });

    $('.glyphicon-saved').on('click', function() {
        $(this).parent().parent().find('input').prop('disabled',true);
        $(this).parent().parent().find('.glyphicon-remove').css('display','inline-block');
        $(this).parent().parent().find('.glyphicon-edit').css('display','inline-block');
        $(this).parent().parent().find('.glyphicon-saved').css('display','none');
        $(this).parent().parent().find('.glyphicon-remove-sign').css('display','none');
        var comment = $(this).parent().parent().find('input').val();
        var commentID = $(this).parent().parent().find('.glyphicon-remove > p').text();
        var data = {};
        data.content = comment;
        $.ajax({
            
            type: 'PUT',
            url: 'http://localhost:3001/posts/commentUpdate/'+commentID,
            data: JSON.stringify(data),
            contentType: 'application/json',
            success: () => {
                location.reload();
            }
        });
    });

    $('.glyphicon-edit').on('click', function() {
        $(this).parent().parent().find('input').prop('disabled',false);
        $(this).parent().parent().find('.glyphicon-remove').css('display','none');
        $(this).parent().parent().find('.glyphicon-edit').css('display','none');
        $(this).parent().parent().find('.glyphicon-saved').css('display','inline-block');
        $(this).parent().parent().find('.glyphicon-remove-sign').css('display','inline-block');
        
        
    });

    $('.glyphicon-remove-sign').on('click', function() {
        $(this).parent().parent().find('input').prop('disabled',true);
        $(this).parent().parent().find('.glyphicon-remove').css('display','inline-block');
        $(this).parent().parent().find('.glyphicon-edit').css('display','inline-block');
        $(this).parent().parent().find('.glyphicon-saved').css('display','none');
        $(this).parent().parent().find('.glyphicon-remove-sign').css('display','none');
        
        
    });

    //Commenting code for a post
    $('#submit-txt-comment').on('click', function() {
      
        console.log("Comment btn  "+ $('#comment-txt-box').val() + " <=");
        console.log($(location).attr('href'));
        var comment = $('#comment-txt-box').val();
        var data = {};
        data.content = comment;
        $.ajax({

            type: 'POST',
            url: 'http://localhost:3001/posts/comments/5caf25e7af7fec802c95d7d5',
            data: JSON.stringify(data),
            contentType: 'application/json',
            success: () => {
                location.reload();
            }
        });

        });


    $('#sign-up-btnn').on('click', function() {
        console.log('click up');
        $('#sign-in-close').click();
    });
    //Close button for sign in sign-in-close

    $('#sign-in-close').on('click', function() {
        console.log('click login');
    });

    //logout 
    $('#header-logout').on('click', function() {
        sessionStorage.clear('token');
        location.reload();
    });
    //Comment when enter is pressed 
    $("#comment-txt-box").keyup(function(event) {
        if (event.keyCode === 13) {
            $("#submit-txt-comment").click();
        }
    });

    //aJax call for sign up api sign-up-act-btn
    $('#sign-up-act-btn-TempNotInUSe').on('click', () => {
        
        // console.log($('#fileinput').prop('files')[0].name);
        var name = $('#orangeForm-name').val();
        var email = $('#orangeForm-email').val();
        var pass = $('#orangeForm-pass').val();
        var profileImage = $('#fileinput').prop('files')[0];
        var data = {};
        data.name = name;
        data.email = email;
        data.password = pass;
        data.UserID = localStorage.getItem('token');
        data.profileImage = profileImage;
        console.log(profileImage.name);
        $.ajax({

            type: 'POST',
            url: 'http://localhost:3001/users/sign-up',
            data: JSON.stringify(data),
            contentType: 'application/json',
            success: () => {
                location.reload();
            }
        });
    });

        //aJax call for sign up api sign-in-act-btn
        $('#login-act-btn').on('click', () => {

            var email = $('#login-email').val();
            var pass = $('#login-password').val();
            
            
            
            var data = {};
            data.email = email;
            data.password = pass;
            $.ajax({
    
                type: 'POST',
                url: 'http://localhost:3001/users/login',
                data: JSON.stringify(data),
                contentType: 'application/json',
                success: (data) => {
                    sessionStorage.setItem('UserID', data.id);
                    sessionStorage.setItem('token', data.Token);
                    sessionStorage.setItem('name', data.name);
                    showUserHasBeenAuthenticated();
                    
                    $('#sign-in-close').click();

                    location.reload();
                }
            });
        });

    //ajax Call for make a post so that we can send token and authenticate that user has authenticated banda

    $('#make-a-post').on('click', () => {

        console.log('Make a post has been clicked');
        $.ajax({

            type: 'GET',
            url: '/posts/make-a-post',
            headers: {
                authorization: "Bearer "+ sessionStorage.getItem('token')
            },
            success: (data) =>{
                
                $("#dynamic-body").append(data);
                $('#make-a-post').click();
                $('#makeAPost >  #UserID').val(sessionStorage.getItem('UserID'));
                //  location.reload();
            }
        });
    });

    // Script to open and close sidebar
    function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
  }
   
  function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
  }
  
  // Modal Image Gallery
  function onClick(element) {
    document.getElementById("img01").src = element.src;
    document.getElementById("modal01").style.display = "block";
    var captionText = document.getElementById("caption");
    captionText.innerHTML = element.alt;
  }

  //this call is to make sure if user is logged in or not in? I yes login button shouldn't displayed. This will make sence I guess
  showUserHasBeenAuthenticated();
});

  
  //uploading images?

  function readURL(input) {
    if (input.files && input.files[0]) {
  
      var reader = new FileReader();
  
      reader.onload = function(e) {
        $('.image-upload-wrap').hide();
  
        $('.file-upload-image').attr('src', e.target.result);
        $('.file-upload-content').show();
  
        $('.image-title').html(input.files[0].name);
      };
  
      reader.readAsDataURL(input.files[0]);
  
    } else {
      removeUpload();
    }
  }
  
  function removeUpload() {
    $('.file-upload-input').replaceWith($('.file-upload-input').clone());
    $('.file-upload-content').hide();
    $('.image-upload-wrap').show();
  }
  $('.image-upload-wrap').bind('dragover', function () {
          $('.image-upload-wrap').addClass('image-dropping');
      });
      $('.image-upload-wrap').bind('dragleave', function () {
          $('.image-upload-wrap').removeClass('image-dropping');
  });
  

  function showUserHasBeenAuthenticated(){
      console.log("Tokn => "+sessionStorage.getItem('token'));
      
    //    sessionStorage.clear('token');
      if(sessionStorage.getItem('token') != null)
      {
        $('#header-login').hide();
        // $("#header-login-wrapper").prepend("<a href = '#' style = 'display: inline-block; color:white; font-weight:bold; ' id ='header-logout'>   Logout </a>");
        $("#header-login-wrapper").prepend("<p style = 'display: inline-block; color:black' >Welcome "+sessionStorage.getItem('name')+"   </p>");
        $('#header-logout').css('display', 'inline-block');
        $("#header-login-wrapper").prepend('<figure class="author-figure mb-0 mr-3 d-inline-block"><img src="/Capture.jpg" style = " width: 30px;border-radius: 50%;" alt="Image" class="img-fluid"></figure>');
        $('#makeAPost >  #UserID').val(sessionStorage.getItem('UserID'));
      
        
        console.log("UserID => "+sessionStorage.getItem('UserID'));
        
      }
      else{

        

      }
      

  }