const router = require("express").Router();
const mongoose = require("mongoose");
const multer = require('multer');
const Post = mongoose.model("Post");
const User = mongoose.model("User");
const Comment = mongoose.model("Comment")
const checkAuth = require('../middlewares/check-auth');

//Image Configuration
//const upload = multer({dest:'uploads/'});
const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'public/')
    },

    filename: function(req, file, cb){
        cb(null, file.originalname)
    }
});

const fileFilter = (req, file, cb) => {
    if(file.mimetype === 'image/jpeg' || file.mimetype === 'image/png' || file.mimetype === 'image/jpg'){
        cb(null, true);
    }
    else{
        cb(null, false);
    }
    
    
};

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5
    },
    fileFilter: fileFilter

        });


router.get("/", async (req, res) => {
    
        const posts = await Post.find({});
       // res.send(posts);

       res.render('home')
});


router.get("/make-a-post", checkAuth, (req, res) => {

   res.render('make-a-post')
});

//Save Custome post in mongoDB
router.post("/save-the-post", upload.single('productImage'), async (req, res) => {
    
    console.log(req.body.UserID);
     await User.findOne({_id: req.body.UserID})
    .then((user) => {

        const post = new Post({
        _id: new mongoose.Types.ObjectId(),
        title: req.body.title,
        category: req.body.category,
        backgroundImage: req.file.filename,
        contentImage: req.file.filename,
        aboutPost: req.body.message,
        userID: user._id

        });
    
    post
    // .select('name price _id productImage')
    .save()
    .then(result => {

        user.posts.push(post._id);
        user
        .save()
        .then(() => {
            res.status(201).json({
                message: 'Post created',
                createdProduct: post
            });
        })
        .catch((err) => {
            res.status(201).json({
                message: 'Post not created due to pushing post id in user model',
                Error: err.message
            });
        })
            

    })
    .catch(err => {
        res.status(500).json({Error: err.message});
    });

    })
    .catch(() => {

        res.status(401).json({Not: 'not found user'})
    });
 
 });

 //Show post individual
 router.get("/show-post-single",  (req, res) => {
    
    // const id = req.params.productID;
    const postID = '5cb9b2c293014da884352769';
    Post.findById(postID)
    .exec()
    .then( doc =>{
        
        
        if(doc)
        {   
            console.log(doc.userID);
          User.findOne({_id: doc.userID})
          .then((result) => {
              var post = {};

              post.doc = doc;
              post.userName = result.name;
              post.profileImage = result.profileImage;
            
            res.render('show-post-single',{post: post});
          })
          .catch(() => {
              res.status(401).json({
                Error: "No User Found for this post Anonymous"
              });
          });
           
        }
        else{
            res.status(404).json({Error: 'Not exist any data for given Product-ID : '+id})
        }
    })
    .catch(err => {
        console.log(err.message);
        res.status(500).json({
            error: err
        });
    });
    // res.render('show-post-single');
 });

router.get("/:postId", async (req, res) => {
   
        const post = await Post.findOne({ _id: req.params.postId })
        res.send(post);
});

router.put("/:postId", async (req, res) => {
  
        const post = await Post.findByIdAndUpdate({
            _id: req.params.postId
        }, req.body, {
            new: true,
            runValidators: true
        });

        res.send(post);
});

router.delete("/:postId", async (req, res) => {

      const post = await Post.findByIdAndRemove({
          _id: req.params.postId
      });
      res.send(post)

});


// router.post("/", async (req, res) => {
    
//         const post = new Post();
//         post.title = req.body.title;
//         post.content = req.body.content;
//         await post.save();
//         res.send(post);
// });

//Comments

router.post('/comments/:postID', async (req, res) => {

    console.log("Comment on a post based on post ID");
   const post = await Post.findOne({_id:req.params.postID});

   const comment =  new Comment();
   comment.content = req.body.content;
   comment.post = post._id;
   await comment.save();

   post.comments.push(comment._id);
   await post.save();

   res.send(comment);
});


//getting comments of post by its ID

router.get('/comment/:postID/', async (req, res) => {

    const post = await Post.findOne({_id:req.params.postID}).populate("comments");
    res.render('comments',{posts:post});
    console.log(post);

});

//Edit Comment

router.put('/commentUpdate/:ID', async (req, res) => {

    console.log('Params => '+ req.params.ID);
    console.log('without stringfy > '+req.body.content);
    console.log('with stringfy ' + JSON.stringify(req.body.content))
    const comment = await Comment.findOneAndUpdate(
        {
            _id: req.params.ID
        },
        req.body,
        {
            new: true, runValidators: true
        }
    );

    res.send(comment);
});

router.delete('/comment/:commentID', async (req, res) => {

    await Comment.findByIdAndRemove(
        {
            _id: req.params.commentID
        }
    );
    res.send({Message: "Deleted Succeed"});
});

module.exports = router;